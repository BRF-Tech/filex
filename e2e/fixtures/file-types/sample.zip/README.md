# Sample archive

Multi-folder zip used by the filex viewer audit.

- data/
- docs/
- scripts/
- assets/

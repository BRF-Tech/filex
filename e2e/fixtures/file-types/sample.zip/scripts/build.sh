#!/usr/bin/env bash
go build -o /out/filex ./cmd/filex

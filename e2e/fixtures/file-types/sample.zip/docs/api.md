# API

- /api/files/manager
- /api/files/archive/list
- /api/files/onlyoffice/config

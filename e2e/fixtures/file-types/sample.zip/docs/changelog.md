# Changelog

## v0.1.10
- richer fixtures
- storage stats
- archive viewer
